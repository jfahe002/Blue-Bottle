--Create statment for the weather data table 


create table weather_data 
(weather_date datetime,
humidity float,
temperature float,
);



--Create statement for the sample data file 


create table sample_data
(local_created_at datetime,
item_name varchar(50),
net_quantity integer
);


--Create statement for the table that joins the weather data into the transaction data

create table sample_weather as (
select a.*, b.*
from 
sample_data a
left join
(select c.*,
case when c.weather_date >= "2016-03-11 00:00:00" and c.weather_date < "2016-09-06" 
then date_sub(c.weather_date, interval 7 hour) 
else date_sub(c.weather_date, interval 8 hour) 
end weather_date_adj
from weather_data c) b
on 
date_format(a.local_created_at, '%Y-%m-%d') = date_format(b.weather_date_adj, '%Y-%m-%d')
and
hour(a.local_created_at) = hour(b.weather_date_adj)
) 
