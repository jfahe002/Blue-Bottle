select temp, item_name, total_sales from 
(
	select temp, item_name, total_sales, rank() over (partition by temp order by total_sales desc) sales_rank
	from (
		select round(temperature) temp, item_name, sum(net_quantity) total_sales
		from sample_weather
		group by 1,2
		) a
	group by 1,2
	order by temp
) b 
where sales_rank = 1
