select a.*, b.warmer_sales from
(
	select item_name, avg(sales_diff) as colder_sales
	from
	(
		select b.*,
		(temp - next_day_temp) as temp_diff,
		(total_sales - next_day_sales) as sales_diff
		from
		(
			select item_name, 
			first_day, 
			next_day, 
			temp, 
			lag(temp,1) over () as next_day_temp, 
			total_sales, 
			lag(total_sales,1) over () as next_day_sales
			from (
				select 
				item_name,
				date_format(local_created_at, '%Y-%m-%d') first_day, 
				date_add(date_format(local_created_at, '%Y-%m-%d'), interval 1 day) next_day, 
				round(avg(temperature)) temp,
				sum(net_quantity) total_sales
				from sample_weather
				group by 1,2,3
				order by 1,2
			) a
		) b
	)c
	where c.temp_diff = 2
	group by 1
) a
join
(	select item_name, avg(sales_diff) as warmer_sales
	from
	(
		select b.*,
		(temp - next_day_temp) as temp_diff,
		(total_sales - next_day_sales) as sales_diff
		from
		(
			select item_name, 
			first_day, 
			next_day, 
			temp, 
			lag(temp,1) over () as next_day_temp, 
			total_sales, 
			lag(total_sales,1) over () as next_day_sales
			from (
				select 
				item_name,
				date_format(local_created_at, '%Y-%m-%d') first_day, 
				date_add(date_format(local_created_at, '%Y-%m-%d'), interval 1 day) next_day, 
				round(avg(temperature)) temp,
				sum(net_quantity) total_sales
				from sample_weather
				group by 1,2,3
				order by 1,2
			) a
		) b
	)c
	where c.temp_diff = -2
	group by 1
) b
on a.item_name = b.item_name